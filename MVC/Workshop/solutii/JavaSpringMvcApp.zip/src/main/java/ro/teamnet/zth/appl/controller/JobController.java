package ro.teamnet.zth.appl.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import ro.teamnet.zth.appl.domain.Job;
import ro.teamnet.zth.appl.service.JobService;

import javax.inject.Inject;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.POST;
import static org.springframework.web.bind.annotation.RequestMethod.PUT;


@Controller
@RequestMapping("/jobs")
public class JobController {
    private final JobService jobService;

    @Inject
    public JobController(JobService jobService) {
        this.jobService = jobService;
    }

    @RequestMapping(value = "/all")
    public
    @ResponseBody
    List<Job> getAll() {
        return jobService.findAll();
    }

    @RequestMapping(value = "/one")
    public
    @ResponseBody
    Job getOne(@RequestParam(name = "id") String jobId) {
        return jobService.findOne(jobId);
    }

//    @RequestMapping(value = "/{id}")
//    public
//    @ResponseBody
//    Job getOne(@PathVariable(value = "id") String jobId) {
//        return jobService.findOne(jobId);
//    }

    @RequestMapping(value = "/one", method = RequestMethod.DELETE)
    public
    @ResponseBody
    Boolean deleteOneEmployee(@RequestParam(name = "id") String jobId) {
        return jobService.delete(jobId);
    }

    @RequestMapping(value = "/create", method = POST)
    public
    @ResponseBody
    Job saveEmployee(@RequestBody Job job) {
        return jobService.save(job);
    }

    @RequestMapping(value = "/edit", method = PUT)
    public
    @ResponseBody
    Job updateEmployee(@RequestBody Job job) {
        return jobService.update(job);
    }

}
