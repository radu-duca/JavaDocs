package ro.teamnet.zth.appl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import ro.teamnet.zth.appl.domain.Employee;
import ro.teamnet.zth.appl.service.EmployeeService;

import java.util.List;

@Controller
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    @Autowired
    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }


    @RequestMapping(value = "/all", method = RequestMethod.GET)
    public
    @ResponseBody
    List<Employee> getAllEmployees() {
        return employeeService.findAllEmployees();
    }

    @RequestMapping(value = "/one", method = RequestMethod.GET)
    public
    @ResponseBody
    Employee getOneEmployee(@RequestParam("id") Long employeeId) {
        return employeeService.findOneEmployee(employeeId);
    }

    @RequestMapping(value = "/one", method = RequestMethod.DELETE)
    public @ResponseBody Boolean deleteOneEmployee(@RequestParam(name = "id") Long employeeId) {
        return employeeService.delete(employeeId);
    }

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public
    @ResponseBody
    Employee saveEmployee(@RequestBody Employee employee) {
        return employeeService.save(employee);
    }

    @RequestMapping(value = "/edit", method = RequestMethod.PUT)
    public
    @ResponseBody
    Employee updateEmployee(@RequestBody Employee employee) {
        return employeeService.update(employee);
    }

}
